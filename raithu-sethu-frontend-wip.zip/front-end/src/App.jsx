import { AuthProvider } from "./context/AuthContext";
import { ToastProvider } from "./context/ToastContext";

/**
 * Raithu Sethu — AgriMarket frontend
 *
 * STATUS (work in progress): API client layer, design tokens, auth/socket/
 * notification/toast contexts, and shared UI primitives are in place.
 * Routing and the actual pages (auth, farmer dashboard, marketplace,
 * bookings, chat, flash sales, admin) are coming in the next pass —
 * this placeholder will be replaced by <RouterProvider /> once those
 * pages exist.
 */
function App() {
  return (
    <ToastProvider>
      <AuthProvider>
        <div className="flex min-h-screen flex-col items-center justify-center bg-cream px-6 text-center">
          <div className="font-display text-3xl font-semibold text-paddy-800">
            రైతు సేతు <span className="text-ink-soft/50">· Raithu Sethu</span>
          </div>
          <p className="mt-3 max-w-md text-ink-soft">
            Frontend foundation is set up — pages are being built next.
          </p>
        </div>
      </AuthProvider>
    </ToastProvider>
  );
}

export default App;
